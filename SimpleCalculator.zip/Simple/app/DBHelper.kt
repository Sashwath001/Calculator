package com.example.simple

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, 1) {

    companion object {
        const val DATABASE_NAME = "Users.db"
        const val TABLE_NAME = "user_table"
        const val COL_1 = "ID"
        const val COL_2 = "USERNAME"
        const val COL_3 = "PASSWORD"
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE $TABLE_NAME (ID INTEGER PRIMARY KEY AUTOINCREMENT, USERNAME TEXT, PASSWORD TEXT)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")       onCreate(db)
    }

    // Method to insert data
    fun insertData(username: String, password: String): Boolean {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(COL_2, username)
        contentValues.put(COL_3, password)
        val result = db.insert(TABLE_NAME, null, contentValues)
        return result != -1L
    }

    // Method to check if username and password match
    fun checkUser(username: String, password: String): Boolean {
        val db = this.readableDatabase
        val cursor: Cursor = db.rawQuery("SELECT * FROM $TABLE_NAME WHERE USERNAME=? AND PASSWORD=?", arrayOf(username, password))
        val result = cursor.count > 0
        cursor.close()
        return result
    }
}

