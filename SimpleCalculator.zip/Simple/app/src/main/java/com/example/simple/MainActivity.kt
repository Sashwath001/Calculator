package com.example.simple

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var usernameEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var displayUsernameTextView: TextView
    private lateinit var loginButton: Button
    private lateinit var myDb: DataBaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        myDb = DataBaseHelper(this)

        usernameEditText = findViewById(R.id.username_input)
        passwordEditText = findViewById(R.id.password_input)
        displayUsernameTextView = findViewById(R.id.username_input)
        loginButton = findViewById(R.id.login_btn)

        loginButton.setOnClickListener(this)

        // Insert a test user
        insertTestUser()
    }

    // Method to insert a test user into the database
    private fun insertTestUser() {
        val username = "Sashwath"
        val password = "password123"
        val isInserted = myDb.insertData(username, password)
        if (isInserted) {
            Toast.makeText(this, "Test User Inserted", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "Failed to Insert Test User", Toast.LENGTH_LONG).show()
        }
    }

    override fun onClick(v: View?) {
        val username = usernameEditText.text.toString().trim()
        val password = passwordEditText.text.toString().trim()

        if (myDb.checkUser(username, password)) {
            displayUsernameTextView.text = "Username: $username"
            val intent = Intent(this, MainActivity2::class.java)
            startActivity(intent)
        } else {
            Toast.makeText(this, "Login Failed. User not found.", Toast.LENGTH_LONG).show()
        }
    }
}
